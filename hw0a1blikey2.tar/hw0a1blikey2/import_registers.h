volatile void * import_registers( void );

