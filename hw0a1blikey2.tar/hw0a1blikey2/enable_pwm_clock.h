/*
 * enable_pwm_clock.h
 *
 *  Created on: Feb 3, 2018
 *      Author: steveb
 */

#ifndef ENABLE_PWM_CLOCK_H_
#define ENABLE_PWM_CLOCK_H_

void enable_pwm_clock( volatile struct io_peripherals *io );

#endif /* ENABLE_PWM_CLOCK_H_ */
